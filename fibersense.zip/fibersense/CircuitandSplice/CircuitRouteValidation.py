"""
/***************************************************************************
 CircuitRouteValidation.py -
                                 A QGIS plugin
 CircuitBuilder Based on Chinese Postman Solver
                              -------------------
        begin                : 2013-05-11
        copyright            : (C) 2013 by Ralf Kistner
        email                : ralf.kistner@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from __future__ import absolute_import

# To reload this plugin after modifying, run:
# qgis.utils.reloadPlugin('circuitbuilder')

from builtins import object


# Import the PyQt and QGIS libraries
from qgis.PyQt.QtCore import  QSettings
from qgis.PyQt.QtWidgets import QMessageBox

from qgis.core import (QgsWkbTypes, QgsApplication, QgsProject, QgsSymbol, QgsSingleSymbolRenderer, QgsVectorLayer,
                       QgsFeature, QgsMapLayer, QgsVectorLayer, QgsPointXY, QgsGeometry, QgsDistanceArea,QgsPointXY,
                        QgsFeature,QgsGeometry)
                
import networkx as nx


# We need to import resources, even though we don't use it directly
from . import resources
from distutils.version import LooseVersion

if LooseVersion(nx.__version__) < LooseVersion('1.11'):
    write_dot = nx.write_dot
else:
    try:
        # import pygraphviz
        from networkx.drawing.nx_agraph import write_dot
    except ImportError:
        try:
            if LooseVersion(nx.__version__) == LooseVersion('1.11'):
                #import pydotplus
                pass
            else:
                #import pydot
                pass
            from networkx.drawing.nx_pydot import write_dot
        except ImportError:
            from networkx.drawing.nx_agraph import write_dot

# Below constant is for changes introduced in NetworkX 2.1rc1, but
# LooseVersion thinks '2.1rc1' is higher than '2.1'. Change to '2.1rc1'
# when switching to pkg_resources.parse_version/packaging.version.parse.
_NX_BELOW_2_DOT_1 = (LooseVersion(nx.__version__) < LooseVersion('2.1'))

    # run method that performs all the real work
def CircuitRouteValidator(self, iface, layer, feedback, diagMessageEnabled):
    layer = self.iface.mapCanvas().currentLayer()
    incompleteBuild = False

    layerHint = "\n\nPlease select a Vector layer of geometry type Line."

    if layer is None:
        QMessageBox.information(None, "Circuit Builder", "No layer selected." +
                                                            layerHint)
        return(False)

    if layer.type() != QgsMapLayer.VectorLayer:
        QMessageBox.information(None, "Circuit Builder", "The selected layer is not of type Vector." +
                                                            layerHint)
        return(False)

    if layer.geometryType() != QgsWkbTypes.LineGeometry:
        QMessageBox.information(None, "Circuit Builder", "The selected layer's geometry type is not Line. " +
                                                            "Circuit Builder cannot work on Point or Polygon." +
                                                            layerHint)
        feedback.pushInfo("The selected layer's geometry type is not Line. " +
                                                            "Circuit Builder cannot work on Point or Polygon." +
                                                            layerHint)
        return(False)

    features = layer.selectedFeatures()
    if len(features) == 0:
        QMessageBox.information(None, "Circuit Builder", "Please select an area. The 'Select Features by Polygon' tool " +
                                                        "works well for this.")
        return(False)

    graph = build_graph(features)
    ## components = circuitbuild.graph_components(graph)
    components = graph_components(graph)
    if len(components) > 1:
        QMessageBox.information(None, "Circuit Builder", "Warning: the selected area contains multiple disconnected " +
                                                            "components - only the largest one will be used.")
        feedback.pushInfo("Warning: the selected area contains multiple disconnected " +
                                                            "components - only the largest one will be used.")
        incompleteBuild = True
    if len(components) == 0:
        QMessageBox.information(None, "Circuit Builder", "Error: Could not find any components. Try selecting different features.")
        return(False)

    component = components[0]
    traversed_nodes = []


    ## eulerian_graph, nodes = circuitbuild.single_chinese_postman_path(component)
    eulerian_graph, nodes, traversed_nodes = single_chinese_postman_path(component)

    # Add the traversed_nodes the map as a point layer
    # We want to set the CRS without prompting the user, so we disable prompting first
    # Extract CRS from your existing layer
    crs = layer.crs().authid()

    # Create an empty Point memory layer with the extracted CRS
    layer_name = "Traversed Nodes"
    mem_layer = QgsVectorLayer(f"Point?crs={crs}&field=id:integer", layer_name, "memory")
    provider = mem_layer.dataProvider()

    # Start editing the memory layer
    mem_layer.startEditing()

    # Assuming traversed_nodes is a list of tuples [(x1, y1), (x2, y2), ...]
    for idx, (x, y) in enumerate(traversed_nodes):
        # Create a new feature, set its geometry, and add to the layer
        feature = QgsFeature()
        feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))  # <-- use QgsPointXY here
        feature.setAttributes([idx])  # Set id or any other attributes you want
        provider.addFeature(feature)

    # Commit changes
    mem_layer.commitChanges()

    # Add the memory layer to the Layers panel in QGIS
    QgsProject.instance().addMapLayer(mem_layer)

    ## in_length = circuitbuild.edge_sum(component)/1000.0
    ## path_length = circuitbuild.edge_sum(eulerian_graph)/1000.0
    in_length = edge_sum(component)/1000.0
    path_length = edge_sum(eulerian_graph)/1000.0
    duplicate_length = path_length - in_length

    newlayer = build_layer(eulerian_graph, nodes, layer.crs())
    symbol = build_symbol(newlayer)
    newlayer.setRenderer(QgsSingleSymbolRenderer(symbol))

    QgsProject.instance().addMapLayer(newlayer)

    if diagMessageEnabled:
        info = ""
        info += "Total length of roads: %.3f km\n" % in_length
        info += "Total length of path: %.3f km\n" % path_length
        info += "Length of sections visited twice: %.3f km\n" % duplicate_length
        info += "\n"
        info += "(If the above values do not make sense, consider changing CRS.)\n"

        QMessageBox.information(None, "Circuit Builder", info)
    if incompleteBuild:
        return(False)
    else:
        return(True)

def build_symbol(layer):
    registry = QgsApplication.symbolLayerRegistry()
    lineMeta = registry.symbolLayerMetadata("SimpleLine")
    markerMeta = registry.symbolLayerMetadata("MarkerLine")

    symbol = QgsSymbol.defaultSymbol(layer.geometryType())

    # Line layer
    lineLayer = lineMeta.createSymbolLayer({'width': '0.26', 'color': '255,0,0', 'offset': '-1.0', 'penstyle': 'solid', 'use_custom_dash': '0', 'joinstyle': 'bevel', 'capstyle': 'square'})

    # Marker layer
    markerLayer = markerMeta.createSymbolLayer({'width': '0.26', 'color': '255,0,0', 'interval': '3', 'rotate': '1', 'placement': 'interval', 'offset': '-1.0'})
    subSymbol = markerLayer.subSymbol()
    # Replace the default layer with our own SimpleMarker
    subSymbol.deleteSymbolLayer(0)
    triangle = registry.symbolLayerMetadata("SimpleMarker").createSymbolLayer({'name': 'filled_arrowhead', 'color': '255,0,0', 'color_border': '0,0,0', 'offset': '0,0', 'size': '1.5', 'angle': '0'})
    subSymbol.appendSymbolLayer(triangle)

    # Replace the default layer with our two custom layers
    symbol.deleteSymbolLayer(0)
    symbol.appendSymbolLayer(lineLayer)
    symbol.appendSymbolLayer(markerLayer)

    return symbol

def build_layer(graph, nodes, crs):
    # create layer

    # We want to set the CRS without prompting the user, so we disable prompting first
    s = QSettings()
    oldValidation = s.value("/Projections/defaultBehaviour", "useGlobal")
    s.setValue("/Projections/defaultBehaviour", "useGlobal")

    vl = QgsVectorLayer("LineString", "chinese_postman", "memory")
    vl.setCrs(crs)

    s.setValue("/Projections/defaultBehaviour", oldValidation)

    pr = vl.dataProvider()

    # We use a single polyline to represent the route
    points = []
    for node in nodes:
        points.append(QgsPointXY(node[0], node[1]))

    # add the feature
    fet = QgsFeature()
    fet.setGeometry(QgsGeometry.fromPolylineXY(points))

    pr.addFeatures([fet])

    # update layer's extent when new features have been added
    # because change of extent in provider is not propagated to the layer
    vl.updateExtents()

    return vl



def build_graph(features):
    d = QgsDistanceArea()
    graph = nx.Graph()
    for feature in features:
        geom = feature.geometry()
        geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
        if geomSingleType:
            nodes = geom.asPolyline()
            ## for start, end in circuitbuild.pairs(nodes):
            for start, end in pairs(nodes):
                graph.add_edge((start[0], start[1]), (end[0], end[1]), weight=d.measureLine(start, end))
        else:
            lines = geom.asMultiPolyline()
            for line in lines:
                ## for start, end in circuitbuild.pairs(line):
                for start, end in pairs(line):
                    graph.add_edge((start[0], start[1]), (end[0], end[1]), weight=d.measureLine(start, end))


    return graph


def pairs(lst, circular=False):
    """
    Loop through all pairs of successive items in a list.

    >>> list(pairs([1, 2, 3, 4]))
    [(1, 2), (2, 3), (3, 4)]
    >>> list(pairs([1, 2, 3, 4], circular=True))
    [(1, 2), (2, 3), (3, 4), (4, 1)]
    """
    i = iter(lst)
    first = prev = item = next(i)
    for item in i:
        yield prev, item
        prev = item
    if circular:
        yield item, first

def graph_components(graph):
    # The graph may contain multiple components, but we can only handle one connected component. If the graph contains
    # more than one connected component, we only use the largest one.
    # Original code below
    #components = list(nx.connected_component_subgraphs(graph))
    #components.sort(key=lambda c: c.size(), reverse=True)

    components = [graph.subgraph(c) for c in nx.connected_components(graph)]
    components.sort(key=lambda c: c.number_of_edges(), reverse=True)

    return components



def odd_graph(graph):
    """
    Given a graph G, construct a graph containing only the vertices with odd degree from G. The resulting graph is
    fully connected, with each weight being the shortest path between the nodes in G.

    Complexity: O(V'*(E + V log(V)) )
    """
    result = nx.Graph()
    odd_nodes = [n for n in graph.nodes() if graph.degree(n) % 2 == 1]
    for u in odd_nodes:
        # We calculate the shortest paths twice here, but the overall performance hit is low
        paths = nx.shortest_path(graph, source=u, weight='weight')
        lengths = nx.shortest_path_length(graph, source=u, weight='weight')
        for v in odd_nodes:
            if u <= v:
                # We only add each edge once
                continue
            # The edge weights are negative for the purpose of max_weight_matching (we want the minimum weight)
            result.add_edge(u, v, weight=-lengths[v], path=paths[v])

    return result


def edge_sum(graph):
    total = 0
    for u, v, data in graph.edges(data=True):
        total += data['weight']
    return total

def matching_cost(graph, matching):
    # Calculate the cost of the additional edges
    cost = 0
    for u, v in (matching.items() if _NX_BELOW_2_DOT_1 else matching):
        if _NX_BELOW_2_DOT_1 and (v <= u):
            continue
        data = graph[u][v]
        cost += abs(data['weight'])
    return cost


def find_matchings(graph, n=5):
    """
    Find the n best matchings for a graph. The best matching is guaranteed to be the best, but the others are only
    estimates.

    A matching is a subset of edges in which no node occurs more than once.

    The result may contain less than n matchings.

    See https://networkx.github.io/documentation/stable/reference/algorithms/generated/networkx.algorithms.matching.max_weight_matching.html
    """
    best_matching = nx.max_weight_matching(graph, True)
    matchings = [best_matching]

    for u, v in (best_matching.items() if _NX_BELOW_2_DOT_1 else best_matching):
        if _NX_BELOW_2_DOT_1 and (v <= u):
            continue
        # Remove the matching
        smaller_graph = nx.Graph(graph)
        smaller_graph.remove_edge(u, v)
        matching = nx.max_weight_matching(smaller_graph, True)
        if len(matching) > 0:
            # We may get an empty matching if there is only one edge (that we removed).
            matchings.append(matching)

    matching_costs = [(matching_cost(graph, matching), matching) for matching in matchings]
    matching_costs.sort(key=lambda k: k[0])

    # HACK: The above code end up giving duplicates of the same path, even though the matching is different. To prevent
    # this, we remove matchings with the same cost.
    final_matchings = []
    last_cost = None
    for cost, matching in matching_costs:
        if cost == last_cost:
            continue
        last_cost = cost
        final_matchings.append((cost, matching))

    return final_matchings


def build_eulerian_graph(graph, odd, matching):
    """
    Build an Eulerian graph from a matching. The result is a MultiGraph.
    """

    # Copy the original graph to a multigraph (so we can add more edges between the same nodes)
    eulerian_graph = nx.MultiGraph(graph)

    # For each matched pair of odd vertices, connect them with the shortest path between them
    for u, v in (matching.items() if _NX_BELOW_2_DOT_1 else matching):
        if _NX_BELOW_2_DOT_1 and (v <= u):
            # With max_weight_matching of NetworkX <2.1 each matching occurs twice in the matchings: (u => v) and (v => u). We only count those where v > u
            continue
        edge = odd[u][v]
        path = edge['path']  # The shortest path between the two nodes, calculated in odd_graph()

        # Add each segment in this path to the graph again
        for p, q in pairs(path):
            eulerian_graph.add_edge(p, q, weight=graph[p][q]['weight'])

    return eulerian_graph

def eulerian_circuit(graph, traversed_nodes):
    """
    Given an Eulerian graph, find one eulerian circuit. Returns the circuit as a list of nodes, with the first and
    last node being the same.
    """

    circuit = list(nx.eulerian_circuit(graph))
    nodes = []
    for u, v in circuit:
        nodes.append(u)
        traversed_nodes.append(u)
    # Close the loop
    nodes.append(circuit[0][0])
    return nodes, traversed_nodes

def chinese_postman_paths(graph, n=5):
    """
    Given a graph, return a list of node id's forming the shortest chinese postman path.
    """

    # Find all the nodes with an odd degree, and create a graph containing only them
    odd = odd_graph(graph)

    # Find the best matching of pairs of odd nodes
    matchings = find_matchings(odd, n)

    paths = []
    for cost, matching in matchings[:n]:
        # Copy the original graph to a multigraph (so we can add more edges between the same nodes)
        eulerian_graph = build_eulerian_graph(graph, odd, matching)

        # Now that we have an eulerian graph, we can calculate the eulerian circuit
        nodes = eulerian_circuit(eulerian_graph)

        paths.append((eulerian_graph, nodes))
    return paths


def single_chinese_postman_path(graph):
    """
    Given a graph, return a list of node id's forming the shortest chinese postman path.

    If we assume V' (number of nodes with odd degree) is at least some constant fraction of V (total number of nodes),
    say 10%, the overall complexity is O(V^3).
    """
    traversed_nodes = []
    # Build a fully-connected graph containing only the odd edges.  Complexity: O(V'*(E + V log(V)) )
    odd = odd_graph(graph)

    # Find the best matching of pairs of odd nodes. Complexity: O(V'^3)
    matching = nx.max_weight_matching(odd, True)

    # Complexity of the remainder is less approximately O(E)
    eulerian_graph = build_eulerian_graph(graph, odd, matching)
    nodes, traversed_nodes = eulerian_circuit(eulerian_graph, traversed_nodes)

    return eulerian_graph, nodes, traversed_nodes